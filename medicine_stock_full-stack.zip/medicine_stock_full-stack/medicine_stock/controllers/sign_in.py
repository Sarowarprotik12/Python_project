
def sign_in():
    name = request.vars.name
    email = request.vars.email
    password = request.vars.password

    if name == '' or name is None or name == "None":
        return response.json({"message": "Name is required", "data": {}})
    elif email == '' or email is None or email == "None":
        return response.json({"message": "Email required", "data": {}})
    elif password == '' or password is None or password == "None":
        return response.json({"message": "Password required", "data": {}})
    else:
        check_sql = "SELECT * FROM sign_in WHERE email='" + str(email) + "' ;"
        check_user = db.executesql(check_sql, as_dict=True)
        if len(check_user) > 0:
            return response.json({"message": "Email already exists", "data": {}})
        else:
            insert_sql = "INSERT INTO sign_in (name, email, password) VALUES ('" + str(name) + "','" + str(email) + "','" + str(password) + "');"
            db.executesql(insert_sql)
            return response.json({"message": "Registration successful!", "data": {}})


# def sign_in():
#     name = request.vars.name
#     email = request.vars.email
#     password = request.vars.password

    # if not (name and email and password):
    #     return response.json({"message": "Missing value! Please fill all fields","data": {} })

    # db.executesql("INSERT INTO sign_in (name, email, password) VALUES ('name', 'email', 'password')")

    # last_id = db.executesql("SELECT LAST_INSERT_ID()", as_dict=True)[0]['LAST_INSERT_ID()']

    # sql = db.executesql("SELECT * FROM sign_in WHERE id=%s",placeholders=(last_id,),as_dict=True)[0]

    # return response.json({"message": "Registration successful","data": sql})













def log_in():
    email = request.vars.email
    password = request.vars.password

    if email == '' or email is None or email == "None":
        return response.json({"message": "Email is required", "data": {}})
    elif password == '' or password is None or password == "None":
        return response.json({"message": "Password is required", "data": {}})
    else:
       
        check_sql = "SELECT * FROM sign_in WHERE email='" + str(email) + "' AND password='" + str(password) + "';"
        user = db.executesql(check_sql, as_dict=True)

        if len(user) > 0:
         
            session.user_id = user[0]['id']    
            return response.json({"message": "Login successful!", "data": user[0]})
        else:
            return response.json({"message": "Invalid email or password", "data": {}})




# def medicines():
#    if request.vars.request_method == "POST":
#     medicine_name = (request.vars.medicine_name or '').strip()
#     medicine_category = (request.vars.medicine_category or '').strip()
#     medicine_price = (request.vars.medicine_price or '').strip()
#     medicine_expiry_date = (request.vars.medicine_expiry_date or '').strip()
#     medicine_stock_count = (request.vars.medicine_stock_count or '').strip()
#     medicine_reorder_level = (request.vars.medicine_reorder_level or '').strip()

#     if medicine_name == '' or medicine_category == '':
#         return response.json({
#             "message": "Medicine name and category are required","data": {}})

#     insert_sql = f"""INSERT INTO medicines (medicine_name, medicine_category, medicine_price, medicine_expiry_date, medicine_stock_count, medicine_reorder_level )VALUES ('{medicine_name}', '{medicine_category}', '{medicine_price}', '{medicine_expiry_date}', '{medicine_stock_count}', '{medicine_reorder_level}')"""
#     db.executesql(insert_sql)

#     sql = "SELECT * FROM medicines"
#     records = db.executesql(sql, as_dict=True)

#     return response.json({"message": "Medicine added successfully!","data": records})



#medicine add
def medicines():
   
    method = request.env.request_method  

    if method == "POST":

        medicine_name = (request.vars.medicine_name or '').strip()
        medicine_category = (request.vars.medicine_category or '').strip()
        medicine_price = (request.vars.medicine_price or '').strip()
        medicine_expiry_date = (request.vars.medicine_expiry_date or '').strip()
        medicine_stock_count = (request.vars.medicine_stock_count or '').strip()
        medicine_reorder_level = (request.vars.medicine_reorder_level or '').strip()

        
        if medicine_name.lower() == 'none':
            medicine_name = ''
        if medicine_category.lower() == 'none':
            medicine_category = ''

     
        if medicine_name == '' or medicine_category == '':
            return response.json({
                "message": "Medicine name and category are required",
                "data": {}
            })

        insert_sql = f"""
        INSERT INTO medicines 
        (medicine_name, medicine_category, medicine_price, medicine_expiry_date, medicine_stock_count, medicine_reorder_level)VALUES ('{medicine_name}', '{medicine_category}', '{medicine_price}', '{medicine_expiry_date}', '{medicine_stock_count}', '{medicine_reorder_level}')"""
        db.executesql(insert_sql)

        message = "Medicine added successfully!"

    else:
        message = "Medicines fetched successfully!"

  
    sql = "SELECT * FROM medicines"
    records = db.executesql(sql, as_dict=True)

    return response.json({"message": message, "data": records})




def edit():
    method = request.env.request_method  

    if method == "PUT":
        id = (request.vars.id or '').strip()
        medicine_name = (request.vars.medicine_name or '').strip()
        medicine_category = (request.vars.medicine_category or '').strip()
        medicine_price = (request.vars.medicine_price or '').strip()
        medicine_expiry_date = (request.vars.medicine_expiry_date or '').strip()
        medicine_stock_count = (request.vars.medicine_stock_count or '').strip()
        medicine_reorder_level = (request.vars.medicine_reorder_level or '').strip()
        

        if id == '':
            return response.json({
                "message": "Medicine ID is required for update",
                "data": {}
            })

        update_sql = f"""
        UPDATE medicines 
        SET medicine_name = '{medicine_name}',
            medicine_category = '{medicine_category}',
            medicine_price = '{medicine_price}',
            medicine_expiry_date = '{medicine_expiry_date}',
            medicine_stock_count = '{medicine_stock_count}',
            medicine_reorder_level = '{medicine_reorder_level}'
        WHERE id = '{id}'
        """
        db.executesql(update_sql)
        message = "Medicine updated successfully!"

    else:
        message = "Medicines fetched successfully!"

    
    id = request.vars.id
    if id:
        sql = f"SELECT * FROM medicines WHERE id = '{id}'"
    else:
        sql = "SELECT * FROM medicines"

    records = db.executesql(sql, as_dict=True)

    return response.json({
        "message": message,
        "data": records
    })




def delete():
    method = request.env.request_method  

    if method == "POST":
        id = (request.vars.id or '').strip()

        if id == '':
            return response.json({
                "message": "Medicine ID is required for delete",
                "data": {}
            })

        try:
            id = int(id)
        except ValueError:
            return response.json({
                "message": "Invalid Medicine ID format",
                "data": {}
            })

        
        delete_sql = f"DELETE FROM medicines WHERE id ={id}"
        db.executesql(delete_sql)

        message = "Medicine deleted successfully!"
    else:
        message = "Medicines fetched successfully!"

    
    sql = "SELECT * FROM medicines"
    records = db.executesql(sql, as_dict=True)

    return response.json({
        "message": message,
        "data": records
    })

