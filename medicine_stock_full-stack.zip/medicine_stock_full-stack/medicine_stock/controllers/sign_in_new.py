def sign_in():
    name = request.vars.name
    email = request.vars.email
    password = request.vars.password

    if name == '' or name is None or name == "None":
        return dict(message="Name is required", data={})
    elif email == '' or email is None or email == "None":
        return dict(message="Email required", data={})
    elif password == '' or password is None or password == "None":
        return dict(message="Password required", data={})
    else:
        check_sql = "SELECT * FROM sign_in WHERE email='" + str(email) + "' ;"
        check_user = db.executesql(check_sql, as_dict=True)
        if len(check_user) > 0:
            return dict(message="Email already exists", data={})
        else:
            insert_sql = "INSERT INTO sign_in (name, email, password) VALUES ('" + str(name) + "','" + str(email) + "','" + str(password) + "');"
            db.executesql(insert_sql)
            db.commit()
            return dict(message="Registration successful!", data={})


















def log_in():
    email = request.vars.email
    password = request.vars.password

    if email == '' or email is None or email == "None":
        return dict(message="Email is required", data={})
    elif password == '' or password is None or password == "None":
        return dict(message="Password is required", data={})
    else:
        check_sql = "SELECT * FROM sign_in WHERE email='" + str(email) + "' AND password='" + str(password) + "';"
        user = db.executesql(check_sql, as_dict=True)

        if len(user) > 0:
            session.user_id = user[0]['id']
            redirect(URL('sign_in_new','medicines'))
        else:
            return dict(message="Invalid email or password", data={})

















def medicines():
    method = request.env.request_method  

    if method == "POST":
        medicine_name = (request.vars.medicine_name or '').strip()
        medicine_category = (request.vars.medicine_category or '').strip()
        medicine_price = (request.vars.medicine_price or '').strip()
        medicine_expiry_date = (request.vars.medicine_expiry_date or '').strip()
        medicine_stock_count = (request.vars.medicine_stock_count or '').strip()
        medicine_reorder_level = (request.vars.medicine_reorder_level or '').strip()

        if medicine_name.lower() == 'none':
            medicine_name = ''
        if medicine_category.lower() == 'none':
            medicine_category = ''

        if medicine_name == '' or medicine_category == '':
            return dict(message="Medicine name and category are required", data={})

        insert_sql = f"""
        INSERT INTO medicines 
        (medicine_name, medicine_category, medicine_price, medicine_expiry_date, medicine_stock_count, medicine_reorder_level)
        VALUES ('{medicine_name}', '{medicine_category}', '{medicine_price}', '{medicine_expiry_date}', '{medicine_stock_count}', '{medicine_reorder_level}')
        """
        db.executesql(insert_sql)
        db.commit()
        message = "Medicine added successfully!"
    else:
        message = "Medicines fetched successfully!"

    sql = "SELECT * FROM medicines"
    records = db.executesql(sql, as_dict=True)

    return dict(message=message, data=records)











def edit():
    method = request.env.request_method  

    if method == "POST":  
        id = (request.vars.id or '').strip()
        medicine_name = (request.vars.medicine_name or '').strip()
        medicine_category = (request.vars.medicine_category or '').strip()
        medicine_price = (request.vars.medicine_price or '').strip()
        medicine_expiry_date = (request.vars.medicine_expiry_date or '').strip()
        medicine_stock_count = (request.vars.medicine_stock_count or '').strip()
        medicine_reorder_level = (request.vars.medicine_reorder_level or '').strip()
        
     
        update_sql = f"""
        UPDATE medicines 
        SET medicine_name = '{medicine_name}',
            medicine_category = '{medicine_category}',
            medicine_price = '{medicine_price}',
            medicine_expiry_date = '{medicine_expiry_date}',
            medicine_stock_count = '{medicine_stock_count}',
            medicine_reorder_level = '{medicine_reorder_level}'
        WHERE id = '{id}'
        """
        db.executesql(update_sql)
        db.commit()

      
        redirect(URL('sign_in_new', 'medicines'))

    else:
       
        id = request.vars.id
        if not id:
            redirect(URL('sign_in_new', 'medicines'))

        sql = f"SELECT * FROM medicines WHERE id = '{id}'"
        records = db.executesql(sql, as_dict=True)
        return dict(message="Edit Medicine", data=records)

    


















def delete():
    method = request.env.request_method  

    if method == "POST":
        id = (request.vars.id or '').strip()

        if id == '':
            return dict(message="Medicine ID is required for delete", data={})

        try:
            id = int(id)
        except ValueError:
            return dict(message="Invalid Medicine ID format", data={})

        delete_sql = f"DELETE FROM medicines WHERE id ={id}"
        db.executesql(delete_sql)
        db.commit()
        message = "Medicine deleted successfully!"
    else:
        message = "Medicines fetched successfully!"

    sql = "SELECT * FROM medicines"
    records = db.executesql(sql, as_dict=True)
    redirect(URL('sign_in_new', 'medicines'))
