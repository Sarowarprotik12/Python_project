from gluon.tools import Auth
db = DAL('mysql://root:@localhost/medicine_stock')